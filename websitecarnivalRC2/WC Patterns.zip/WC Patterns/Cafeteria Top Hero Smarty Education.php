<?php
/**
 * Title: Cafeteria Top Hero
 * Slug: cafeteria-top-hero
 * Categories: Hero
 * Keywords: hero, group, cover, school, smarty education, education
 * Inserter: yes
 */
 ?>
<!-- wp:group {"align":"full","className":"is-style-no-block-gap"} -->
<div class="wp-block-group alignfull is-style-no-block-gap"><!-- wp:cover {"url":"https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/pleasant-woman-giving-lunch-school-boy-cafeteria.jpg","id":287,"dimRatio":10,"overlayColor":"foreground","focalPoint":{"x":"0.38","y":"0.26"},"minHeight":532,"isDark":false} -->
<div class="wp-block-cover is-light" style="min-height:532px"><span aria-hidden="true" class="has-foreground-background-color has-background-dim-10 wp-block-cover__gradient-background has-background-dim"></span><img class="wp-block-cover__image-background wp-image-287" alt="" src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/pleasant-woman-giving-lunch-school-boy-cafeteria.jpg" style="object-position:38% 26%" data-object-fit="cover" data-object-position="38% 26%"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"contentSize":"1100px"}} -->
<div class="wp-block-group"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"},"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center" style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:column {"verticalAlignment":"center","width":"450px","style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px"}},"color":{"background":"#011b3bba"},"border":{"radius":"10px","width":"0px","style":"none"}}} -->
<div class="wp-block-column is-vertically-aligned-center has-background" style="background-color:#011b3bba;border-radius:10px;border-style:none;border-width:0px;margin-top:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px;flex-basis:450px"><!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"35px"},"spacing":{"margin":{"top":"0px","right":"0px","bottom":"10px","left":"0px"}}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:35px;margin-top:0px;margin-right:0px;margin-bottom:10px;margin-left:0px">Cafeteria</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontStyle":"normal","fontWeight":"400","fontSize":"16px"},"spacing":{"margin":{"top":"0px","right":"0px","bottom":"25px","left":"0px"}}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400;margin-top:0px;margin-right:0px;margin-bottom:25px;margin-left:0px">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"textColor":"background","style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"500"},"spacing":{"padding":{"top":"15px","right":"30px","bottom":"15px","left":"30px"}}},"fontFamily":"gilda-display"} -->
<div class="wp-block-button has-custom-font-size has-gilda-display-font-family" style="font-size:18px;font-style:normal;font-weight:500"><a class="wp-block-button__link has-background-color has-text-color" href="https://themes.websitecarnival.com/school/" style="padding-top:15px;padding-right:30px;padding-bottom:15px;padding-left:30px">Read More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->