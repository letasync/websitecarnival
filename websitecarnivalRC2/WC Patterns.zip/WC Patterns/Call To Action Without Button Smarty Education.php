<?php
/**
 * Title: Call To Action Without Button
 * Slug: call-to-action-without-button
 * Categories: Call-to-action
 * Keywords: call to action, school, smarty education, education
 * Inserter: yes
 */
 ?>
<!-- wp:group {"align":"full","className":"is-style-no-block-gap"} -->
<div class="wp-block-group alignfull is-style-no-block-gap"><!-- wp:cover {"url":"https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/school-buses-orlando-florida-usa.jpg","id":236,"hasParallax":true,"dimRatio":50,"overlayColor":"tertiary","minHeight":50,"minHeightUnit":"px","isDark":false} -->
<div class="wp-block-cover is-light has-parallax" style="background-image:url(https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/school-buses-orlando-florida-usa.jpg);min-height:50px"><span aria-hidden="true" class="has-tertiary-background-color wp-block-cover__gradient-background has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"contentSize":"1100px"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"10px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"30px"}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:30px;margin-top:10px;margin-right:0px;margin-bottom:0px;margin-left:0px">Bus Routes</h2>
<!-- /wp:heading -->

<!-- wp:separator {"className":"has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-default"} -->
<hr class="wp-block-separator has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-default"/>
<!-- /wp:separator -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400">Getting your child to and from school safety is our number one priority.<br>Students who are independent and confident, inquisitive and enthusiastic,<br>responsible and compassionate.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->