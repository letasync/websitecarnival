<?php
/**
 * Title: contact page two coloum map with content
 * Slug: websitecarnival/contact page two coloum map with content
 * Categories: Contact
 * Keywords: Service, grid, column
 * Inserter: yes
 */
 ?>
 <!-- wp:group {"className":"is-style-default"} -->
<div class="wp-block-group is-style-default"><!-- wp:group {"className":"is-style-no-block-gap"} -->
<div class="wp-block-group is-style-no-block-gap"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"66.66%"} -->
<div class="wp-block-column" style="flex-basis:66.66%"><!-- wp:wpmapblock/wp-map-block {"map_id":"wpmapblock_021b23f6"} /-->

<!-- wp:heading {"style":{"spacing":{"padding":{"right":"15px","left":"15px"}}},"fontSize":"normal","fontFamily":"lora"} -->
<h2 class="has-lora-font-family has-normal-font-size" style="padding-right:15px;padding-left:15px">| ABOUT US</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"right":"15px","left":"15px"}}},"fontSize":"smaller"} -->
<p class="has-smaller-font-size" style="font-style:normal;font-weight:400;padding-right:15px;padding-left:15px">Far strung contrary tiger uselessly one we religious assenting peculiar oh far compa tible one terrier ahead ape well be to emu sweeping. Far strung contrary tiger uselessly one we religious</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"right":"15px","left":"15px"}}},"fontSize":"smaller"} -->
<p class="has-smaller-font-size" style="font-style:normal;font-weight:400;padding-right:15px;padding-left:15px">Far strung contrary tiger uselessly one we religious assenting peculiar oh far compa tible one terrier ahead ape well be to emu sweeping. Far strung contrary tiger uselessly one we religious</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"33.33%"} -->
<div class="wp-block-column" style="flex-basis:33.33%"><!-- wp:heading {"style":{"spacing":{"padding":{"right":"15px","left":"15px"}}},"fontSize":"normal","fontFamily":"lora"} -->
<h2 class="has-lora-font-family has-normal-font-size" style="padding-right:15px;padding-left:15px">| ABOUT US</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"right":"15px","left":"15px"}}},"fontSize":"smaller"} -->
<p class="has-smaller-font-size" style="font-style:normal;font-weight:400;padding-right:15px;padding-left:15px">Far strung contrary tiger uselessly one we religious assenting peculiar oh far compa tible one terrier ahead ape well be to emu sweeping. Far strung contrary tiger uselessly one we religious</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"right":"15px","left":"15px"}}},"fontSize":"smaller"} -->
<p class="has-smaller-font-size" style="font-style:normal;font-weight:400;padding-right:15px;padding-left:15px">Strung contrary tiger uselessly<br>Religious assenting peculiar<br>Far compatible one terrier ahead<br>Well be to emu sweeping.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"style":{"spacing":{"padding":{"right":"15px","left":"15px"}}},"fontSize":"normal","fontFamily":"lora"} -->
<h2 class="has-lora-font-family has-normal-font-size" style="padding-right:15px;padding-left:15px">| TWITTER</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"padding":{"right":"15px","left":"15px"}},"typography":{"fontStyle":"normal","fontWeight":"400"}},"fontSize":"smaller"} -->
<p class="has-smaller-font-size" style="font-style:normal;font-weight:400;padding-right:15px;padding-left:15px">NO TWEET</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"style":{"spacing":{"padding":{"right":"15px","left":"15px"}}},"fontSize":"normal","fontFamily":"lora"} -->
<h2 class="has-lora-font-family has-normal-font-size" style="padding-right:15px;padding-left:15px">| FACEBOOK</h2>
<!-- /wp:heading -->

<!-- wp:image {"id":469,"sizeSlug":"full","linkDestination":"none","style":{"spacing":{"padding":{"right":"15px","left":"15px"}}}} -->
<figure class="wp-block-image size-full" style="padding-right:15px;padding-left:15px"><img src="https://themes.websitecarnival.com/hotel/wp-content/uploads/sites/8/2022/04/facebook-image.png" alt="" class="wp-image-469"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->