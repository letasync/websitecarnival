<?php
/**
 * Title: title with two coloum
 * Slug: websitecarnival/title with two coloum
 * Categories: Service
 * Keywords: Service, two coloum image with text,title with two coloum
 * Inserter: yes
 */
 ?>
 <!-- wp:group {"className":"is-style-no-block-gap"} -->
<div class="wp-block-group is-style-no-block-gap"><!-- wp:heading {"textAlign":"center","style":{"spacing":{"padding":{"right":"15px","left":"15px"},"margin":{"top":"25px"}},"typography":{"fontStyle":"normal","fontWeight":"400"}},"fontFamily":"lora"} -->
<h2 class="has-text-align-center has-lora-font-family" style="font-style:normal;font-weight:400;margin-top:25px;padding-right:15px;padding-left:15px">DOLLARS AVERAGE PRICE</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"0px","bottom":"20px"},"padding":{"right":"15px","left":"15px"}}},"fontSize":"smaller"} -->
<p class="has-text-align-center has-smaller-font-size" style="margin-top:0px;margin-bottom:20px;padding-right:15px;padding-left:15px">This Telepathically much and meant that far more blank bird then firefly circa up until after logically.</p>
<!-- /wp:paragraph -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center","width":"66.66%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:66.66%"><!-- wp:image {"align":"center","id":545,"sizeSlug":"full","linkDestination":"none","style":{"spacing":{"padding":{"right":"15px","left":"15px"}}}} -->
<figure class="wp-block-image aligncenter size-full" style="padding-right:15px;padding-left:15px"><img src="https://themes.websitecarnival.com/hotel/wp-content/uploads/sites/8/2022/04/luxury-hotel.webp" alt="" class="wp-image-545"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"33.33%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:33.33%"><!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"top":"0px","right":"15px","left":"15px"}}},"fontSize":"smaller"} -->
<p class="has-smaller-font-size" style="font-style:normal;font-weight:400;padding-top:0px;padding-right:15px;padding-left:15px">This telepathically much and meant that far more blank bird then firefly circa up until after logically folded hello. This telepathically much and meant that far more blank bird then firefly circa up until after logically folded hello despite less gosh cassowary far after crud alas alas oriole said oyster cuckoo and knelt alas regardless more squirrel irrespective stuck tragically regardless manful thick to earthworm.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"style":{"typography":{"fontStyle":"normal","fontWeight":"300"}},"className":"is-style-arrow","fontSize":"smaller","fontFamily":"lora"} -->
<ul class="is-style-arrow has-lora-font-family has-smaller-font-size" style="font-style:normal;font-weight:300"><li>This telepathically much and meant that far more blank</li><li>Hello despite less gosh cassowary far after crud alas alas</li><li>Oriole said oyster cuckoo and knelt alas regardless more squirrel</li><li>It is a long established fact that a reader will be distracted .</li><li>It is a long established fact that a reader will be distracted .</li></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->