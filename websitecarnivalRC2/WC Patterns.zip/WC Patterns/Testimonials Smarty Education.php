<?php
/**
 * Title: Testimonials
 * Slug: testimonials
 * Categories: Grid
 * Keywords: columns, testimonials, school, smarty education, education
 * Inserter: yes
 */
 ?>
<!-- wp:group {"align":"full","className":"is-style-no-block-gap"} -->
<div class="wp-block-group alignfull is-style-no-block-gap"><!-- wp:cover {"url":"https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/group-children-art-class_236854-20325-1.webp","id":141,"hasParallax":true,"dimRatio":50,"overlayColor":"tertiary","isDark":false} -->
<div class="wp-block-cover is-light has-parallax" style="background-image:url(https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/group-children-art-class_236854-20325-1.webp)"><span aria-hidden="true" class="has-tertiary-background-color wp-block-cover__gradient-background has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"contentSize":"1100px"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"10px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"30px"}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:30px;margin-top:10px;margin-right:0px;margin-bottom:0px;margin-left:0px">Alumni Testimonials</h2>
<!-- /wp:heading -->

<!-- wp:separator {"className":"has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-default"} -->
<hr class="wp-block-separator has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-default"/>
<!-- /wp:separator -->

<!-- wp:columns {"style":{"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}}} -->
<div class="wp-block-columns" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:column {"style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px","bottom":"10px"}},"border":{"style":"none","width":"0px"}}} -->
<div class="wp-block-column" style="border-style:none;border-width:0px;margin-top:10px;margin-bottom:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"bottom":"10px"}}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400;padding-bottom:10px">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"0px","right":"0px","bottom":"5px","left":"0px"}},"typography":{"fontSize":"20px"}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:20px;margin-top:0px;margin-right:0px;margin-bottom:5px;margin-left:0px">Alia Sabur </h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"15px"}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:15px;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px">Teacher Envato</p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":148,"width":70,"height":70,"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":"0px"},"spacing":{"margin":{"top":"10px"}}},"className":"aligncenter size-full is-resized is-style-rounded"} -->
<div class="wp-block-image aligncenter size-full is-resized is-style-rounded" style="border-radius:0px;margin-top:10px"><figure class="aligncenter size-full is-resized"><img src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/portrait-young-smiling-woman.jpg" alt="" class="wp-image-148" width="70" height="70"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px","bottom":"10px"}},"border":{"width":"0px","style":"none"}}} -->
<div class="wp-block-column" style="border-style:none;border-width:0px;margin-top:10px;margin-bottom:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"bottom":"10px"}}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400;padding-bottom:10px">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"0px","right":"0px","bottom":"5px","left":"0px"}},"typography":{"fontSize":"20px"}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:20px;margin-top:0px;margin-right:0px;margin-bottom:5px;margin-left:0px">Jacob Albert</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"18px"}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:18px;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px">Teacher Envato</p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":149,"width":70,"height":70,"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":"0px"},"spacing":{"margin":{"top":"10px"}}},"className":"aligncenter size-full is-resized is-style-rounded"} -->
<div class="wp-block-image aligncenter size-full is-resized is-style-rounded" style="border-radius:0px;margin-top:10px"><figure class="aligncenter size-full is-resized"><img src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/smiling-man-with-crossed-arms.jpg" alt="" class="wp-image-149" width="70" height="70"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->