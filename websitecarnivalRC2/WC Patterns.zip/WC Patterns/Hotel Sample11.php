<?php
/**
 * Title: Blog grid format1
 * Slug: websitecarnival/Blog grid format1
 * Categories:Service
 * Keywords:  image,Blog,Blog grid,
 * Inserter: yes
 */
 ?>
 <!-- wp:query {"queryId":1,"query":{"offset":0,"perPage":10,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","sticky":"","inherit":false,"taxQuery":{"category":[4]}},"displayLayout":{"type":"flex","columns":3},"align":""} -->
<div class="wp-block-query"><!-- wp:post-template -->
<!-- wp:group {"style":{"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}},"backgroundColor":"white"} -->
<div class="wp-block-group has-white-background-color has-background" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:post-featured-image /-->

<!-- wp:group {"backgroundColor":"white","className":"is-style-no-block-gap"} -->
<div class="wp-block-group is-style-no-block-gap has-white-background-color has-background"><!-- wp:post-title {"isLink":true,"className":"is-style-links-underline-on-hover","fontSize":"normal"} /-->

<!-- wp:post-excerpt {"fontSize":"smaller"} /-->

<!-- wp:separator {"className":"has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-wide"} -->
<hr class="wp-block-separator has-alpha-channel-opacity has-text-color has-primary-color has-primary-background-color has-background is-style-wide"/>
<!-- /wp:separator -->

<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:post-author {"showAvatar":false} /-->

<!-- wp:post-date {"textColor":"primary"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
<!-- /wp:post-template -->

<!-- wp:query-pagination {"paginationArrow":"arrow","layout":{"type":"flex","justifyContent":"space-between"}} -->
<!-- wp:query-pagination-previous {"className":"is-style-links-underline-on-hover"} /-->

<!-- wp:query-pagination-numbers {"className":"is-style-links-underline-on-hover"} /-->

<!-- wp:query-pagination-next {"className":"is-style-links-underline-on-hover"} /-->
<!-- /wp:query-pagination --></div>
<!-- /wp:query -->
