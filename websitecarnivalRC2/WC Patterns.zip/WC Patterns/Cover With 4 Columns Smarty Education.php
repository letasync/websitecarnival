<?php
/**
 * Title: Cover With 4 Columns
 * Slug: cover-with-4-columns
 * Categories: Service
 * Keywords: cover, 4 columns, school, smarty education, education
 * Inserter: yes
 */
 ?>
<!-- wp:group {"align":"full","className":"is-style-no-block-gap"} -->
<div class="wp-block-group alignfull is-style-no-block-gap"><!-- wp:cover {"url":"https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/disabled-pupil-smiling-camera-classroom_13339-266373.webp","id":115,"hasParallax":true,"dimRatio":80,"overlayColor":"tertiary","minHeight":448,"minHeightUnit":"px"} -->
<div class="wp-block-cover has-parallax" style="background-image:url(https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/disabled-pupil-smiling-camera-classroom_13339-266373.webp);min-height:448px"><span aria-hidden="true" class="has-tertiary-background-color has-background-dim-80 wp-block-cover__gradient-background has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"contentSize":"1100px"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"10px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"30px"}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:30px;margin-top:10px;margin-right:0px;margin-bottom:0px;margin-left:0px">Our Goals</h2>
<!-- /wp:heading -->

<!-- wp:separator {"className":"has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-default"} -->
<hr class="wp-block-separator has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-default"/>
<!-- /wp:separator -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400">Here you can review some statistics about our School</p>
<!-- /wp:paragraph -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"10px","right":"10px","bottom":"10px","left":"10px"}}}} -->
<div class="wp-block-column is-vertically-aligned-center" style="padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px"><!-- wp:group {"style":{"spacing":{"margin":{"top":"15px"},"padding":{"top":"10px","right":"10px","bottom":"10px","left":"10px"}},"border":{"width":"1px","style":"solid"}},"borderColor":"lightgrey","layout":{"type":"flex","allowOrientation":false,"flexWrap":"nowrap","justifyContent":"left"}} -->
<div class="wp-block-group has-border-color has-lightgrey-border-color" style="border-style:solid;border-width:1px;margin-top:15px;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px"><!-- wp:image {"id":118,"width":55,"height":55,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/g824-1.png" alt="" class="wp-image-118" width="55" height="55"/></figure>
<!-- /wp:image -->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontSize":"25px"}},"fontFamily":"gilda-display"} -->
<h2 class="has-gilda-display-font-family" style="font-size:25px">112</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}}} -->
<p style="font-size:18px;font-style:normal;font-weight:400;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px">Certified Teachers</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"10px","right":"10px","bottom":"10px","left":"10px"}}}} -->
<div class="wp-block-column is-vertically-aligned-center" style="padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px"><!-- wp:group {"style":{"spacing":{"margin":{"top":"15px"},"padding":{"top":"10px","right":"10px","bottom":"10px","left":"10px"}},"border":{"width":"1px","style":"solid"}},"borderColor":"lightgrey","layout":{"type":"flex","allowOrientation":false,"flexWrap":"nowrap","justifyContent":"left"}} -->
<div class="wp-block-group has-border-color has-lightgrey-border-color" style="border-style:solid;border-width:1px;margin-top:15px;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px"><!-- wp:image {"id":119,"width":51,"height":38,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/HOUSE-34.png" alt="" class="wp-image-119" width="51" height="38"/></figure>
<!-- /wp:image -->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontSize":"25px"}},"fontFamily":"gilda-display"} -->
<h2 class="has-gilda-display-font-family" style="font-size:25px">282,673</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"right":"0px","bottom":"0px","left":"0px","top":"0px"}}}} -->
<p style="font-size:18px;font-style:normal;font-weight:400;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px">Students Enrolled</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"10px","right":"10px","bottom":"10px","left":"10px"}}}} -->
<div class="wp-block-column is-vertically-aligned-center" style="padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px"><!-- wp:group {"style":{"spacing":{"margin":{"top":"15px"},"padding":{"top":"10px","right":"10px","bottom":"10px","left":"10px"}},"border":{"width":"1px","style":"solid"}},"borderColor":"lightgrey","layout":{"type":"flex","allowOrientation":false,"flexWrap":"nowrap","justifyContent":"left"}} -->
<div class="wp-block-group has-border-color has-lightgrey-border-color" style="border-style:solid;border-width:1px;margin-top:15px;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px"><!-- wp:image {"id":120,"width":44,"height":51,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/g847.png" alt="" class="wp-image-120" width="44" height="51"/></figure>
<!-- /wp:image -->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontSize":"25px"}},"fontFamily":"gilda-display"} -->
<h2 class="has-gilda-display-font-family" style="font-size:25px">97%</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}}} -->
<p style="font-size:18px;font-style:normal;font-weight:400;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px">Passing </p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"10px","right":"10px","bottom":"10px","left":"10px"}}}} -->
<div class="wp-block-column is-vertically-aligned-center" style="padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px"><!-- wp:group {"style":{"spacing":{"margin":{"top":"15px"},"padding":{"top":"10px","right":"10px","bottom":"10px","left":"10px"}},"border":{"width":"1px","style":"solid"}},"borderColor":"lightgrey","layout":{"type":"flex","allowOrientation":false,"flexWrap":"nowrap","justifyContent":"left"}} -->
<div class="wp-block-group has-border-color has-lightgrey-border-color" style="border-style:solid;border-width:1px;margin-top:15px;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px"><!-- wp:image {"id":121,"width":35,"height":37,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/path2-2.png" alt="" class="wp-image-121" width="35" height="37"/></figure>
<!-- /wp:image -->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontSize":"25px"}},"fontFamily":"gilda-display"} -->
<h2 class="has-gilda-display-font-family" style="font-size:25px">100%</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}}} -->
<p style="font-size:18px;font-style:normal;font-weight:400;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px">Satisfied Parents</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->