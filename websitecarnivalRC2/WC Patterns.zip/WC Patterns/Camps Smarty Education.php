<?php
/**
 * Title: Camps
 * Slug: camps
 * Categories: Fullpage
 * Keywords: fullpage, school, smarty education, education
 * Inserter: yes
 */
 ?>
<!-- wp:group {"align":"full"} -->
<div class="wp-block-group alignfull"><!-- wp:group {"align":"full","className":"is-style-no-block-gap"} -->
<div class="wp-block-group alignfull is-style-no-block-gap"><!-- wp:cover {"url":"https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/athlete-ready-run-with-are-you-ready-message.jpg","id":902,"dimRatio":0,"focalPoint":{"x":"0.44","y":"0.32"},"minHeight":532,"minHeightUnit":"px","isDark":false} -->
<div class="wp-block-cover is-light" style="min-height:532px"><span aria-hidden="true" class="has-background-dim-0 wp-block-cover__gradient-background has-background-dim"></span><img class="wp-block-cover__image-background wp-image-902" alt="" src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/athlete-ready-run-with-are-you-ready-message.jpg" style="object-position:44% 32%" data-object-fit="cover" data-object-position="44% 32%"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"contentSize":"1100px"}} -->
<div class="wp-block-group"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"},"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center" style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:column {"verticalAlignment":"center","width":"450px","style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px"}},"color":{"background":"#011b3bba"},"border":{"radius":"10px","width":"0px","style":"none"}}} -->
<div class="wp-block-column is-vertically-aligned-center has-background" style="background-color:#011b3bba;border-radius:10px;border-style:none;border-width:0px;margin-top:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px;flex-basis:450px"><!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"35px"},"spacing":{"margin":{"top":"0px","right":"0px","bottom":"10px","left":"0px"}}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:35px;margin-top:0px;margin-right:0px;margin-bottom:10px;margin-left:0px">Camps</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontStyle":"normal","fontWeight":"400","fontSize":"16px"},"spacing":{"margin":{"top":"0px","right":"0px","bottom":"25px","left":"0px"}}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400;margin-top:0px;margin-right:0px;margin-bottom:25px;margin-left:0px">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"textColor":"background","style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"500"},"spacing":{"padding":{"top":"15px","right":"30px","bottom":"15px","left":"30px"}}},"fontFamily":"gilda-display"} -->
<div class="wp-block-button has-custom-font-size has-gilda-display-font-family" style="font-size:18px;font-style:normal;font-weight:500"><a class="wp-block-button__link has-background-color has-text-color" href="https://themes.websitecarnival.com/school/" style="padding-top:15px;padding-right:30px;padding-bottom:15px;padding-left:30px">Back To Home</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"}}},"className":"is-style-no-block-gap"} -->
<div class="wp-block-group alignfull is-style-no-block-gap" style="padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:group {"layout":{"contentSize":"1100px"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"id":347,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/group-kids-going-school-together_109285-2833-1.webp" alt="" class="wp-image-347"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"}}}} -->
<div class="wp-block-column" style="padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"10px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"30px"}},"textColor":"foreground","fontFamily":"gilda-display"} -->
<h2 class="has-foreground-color has-text-color has-gilda-display-font-family" style="font-size:30px;margin-top:10px;margin-right:0px;margin-bottom:0px;margin-left:0px">Language Immersion Summer Camp</h2>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"flex"}} -->
<div class="wp-block-group"><!-- wp:separator {"className":"has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background"} -->
<hr class="wp-block-separator has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background"/>
<!-- /wp:separator --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"left","style":{"typography":{"fontStyle":"normal","fontWeight":"400","fontSize":"16px"}},"textColor":"foreground"} -->
<p class="has-text-align-left has-foreground-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400">Register early — Camps fill quickly! With enough demand, we will open secondary sections of Popular Camps.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"style":{"spacing":{"margin":{"top":"10px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"30px"}},"textColor":"foreground","fontFamily":"gilda-display"} -->
<h2 class="has-foreground-color has-text-color has-gilda-display-font-family" style="font-size:30px;margin-top:10px;margin-right:0px;margin-bottom:0px;margin-left:0px">2016 Camp Dates</h2>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"flex"}} -->
<div class="wp-block-group"><!-- wp:separator {"className":"has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background"} -->
<hr class="wp-block-separator has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background"/>
<!-- /wp:separator --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}}} -->
<p style="font-size:16px;font-style:normal;font-weight:400">Session 1: 6/20 — 7/1/16<br>Session 2: 7/5 — 7/15/16<br>(No Camp Monday July 4th)<br>Session 3: 7/18 — 7/29/16</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"20px","bottom":"30px"}}},"className":"is-style-no-block-gap"} -->
<div class="wp-block-group alignfull is-style-no-block-gap" style="padding-top:20px;padding-bottom:30px"><!-- wp:group {"style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"}}},"layout":{"contentSize":"1100px"}} -->
<div class="wp-block-group" style="padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"66.66%","style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px","bottom":"10px"}},"border":{"width":"1px","style":"solid"}},"borderColor":"lightgrey"} -->
<div class="wp-block-column has-border-color has-lightgrey-border-color" style="border-style:solid;border-width:1px;margin-top:10px;margin-bottom:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px;flex-basis:66.66%"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"10px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"30px"}},"textColor":"foreground","fontFamily":"gilda-display"} -->
<h2 class="has-foreground-color has-text-color has-gilda-display-font-family" style="font-size:30px;margin-top:10px;margin-right:0px;margin-bottom:0px;margin-left:0px">Camp Includes</h2>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"flex"}} -->
<div class="wp-block-group"><!-- wp:separator {"className":"has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background"} -->
<hr class="wp-block-separator has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background"/>
<!-- /wp:separator --></div>
<!-- /wp:group -->

<!-- wp:list {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}}} -->
<ul style="font-size:16px;font-style:normal;font-weight:400"><li>Small groups with teachers from around the world</li></ul>
<!-- /wp:list -->

<!-- wp:list {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}}} -->
<ul style="font-size:16px;font-style:normal;font-weight:400"><li>Fun outdoor and indoor activities aimed at building language skills (songs, folktales, crafts, games, sports, and more)</li></ul>
<!-- /wp:list -->

<!-- wp:list {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}}} -->
<ul style="font-size:16px;font-style:normal;font-weight:400"><li>Cultural performances</li></ul>
<!-- /wp:list -->

<!-- wp:list {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}}} -->
<ul style="font-size:16px;font-style:normal;font-weight:400"><li>Ice-cream social</li></ul>
<!-- /wp:list -->

<!-- wp:list {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}}} -->
<ul style="font-size:16px;font-style:normal;font-weight:400"><li>Special classes with trained specialists- yoga, sports &amp; games</li></ul>
<!-- /wp:list -->

<!-- wp:list {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}}} -->
<ul style="font-size:16px;font-style:normal;font-weight:400"><li>Exciting field days (water balloon toss, relay races, and more)</li></ul>
<!-- /wp:list -->

<!-- wp:list {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}}} -->
<ul style="font-size:16px;font-style:normal;font-weight:400"><li>Fun, cultural music and movement classes for all campers! We will offer different opportunities each session — last year we learned Taiko Drumming, Kung-Fu Martial Arts, and Latin dance!</li></ul>
<!-- /wp:list -->

<!-- wp:list {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}}} -->
<ul style="font-size:16px;font-style:normal;font-weight:400"><li>Field trips for Orange, Purple, Blue and Green camps! Specific information about each field trip will be released one week prior to the start of each camp session.</li></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"33.33%","style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px","bottom":"10px"}},"border":{"width":"1px","style":"solid"}},"borderColor":"lightgrey"} -->
<div class="wp-block-column has-border-color has-lightgrey-border-color" style="border-style:solid;border-width:1px;margin-top:10px;margin-bottom:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px;flex-basis:33.33%"><!-- wp:group {"style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"}}},"backgroundColor":"secondary"} -->
<div class="wp-block-group has-secondary-background-color has-background" style="padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"10px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"30px"}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-background-color has-text-color has-gilda-display-font-family" style="font-size:30px;margin-top:10px;margin-right:0px;margin-bottom:0px;margin-left:0px">Camp at a Glance</h2>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"flex"}} -->
<div class="wp-block-group"><!-- wp:separator {"className":"has-text-color has-background-color has-alpha-channel-opacity has-background-background-color has-background"} -->
<hr class="wp-block-separator has-text-color has-background-color has-alpha-channel-opacity has-background-background-color has-background"/>
<!-- /wp:separator --></div>
<!-- /wp:group -->

<!-- wp:list {"ordered":true,"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}},"textColor":"background","className":"is-style-square"} -->
<ol class="is-style-square has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400"><li>Choose a language (Spanish, Chinese or Japanese)</li></ol>
<!-- /wp:list -->

<!-- wp:list {"ordered":true,"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}},"textColor":"background","className":"is-style-square"} -->
<ol class="is-style-square has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400"><li>Choose a section appropriate for your child’s age and fluency level (see chart below)</li></ol>
<!-- /wp:list -->

<!-- wp:list {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}},"textColor":"background","className":"is-style-square"} -->
<ul class="is-style-square has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400"><li>Choose the two-week session(s) you`d like to attend. All camp sections are available every session in Spanish, Chinese &amp; Japanese</li></ul>
<!-- /wp:list -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontStyle":"normal","fontWeight":"400","fontSize":"16px"}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400">New exciting themes and activities every session. Have fun in one session or all three!</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"20px","bottom":"20px","right":"20px","left":"20px"}},"color":{"background":"#ebebeb52"}},"className":"is-style-no-block-gap","layout":{"inherit":false}} -->
<div class="wp-block-group alignfull is-style-no-block-gap has-background" style="background-color:#ebebeb52;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:group {"style":{"border":{"width":"0px","style":"none"},"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}},"layout":{"contentSize":"1100px","inherit":false}} -->
<div class="wp-block-group" style="border-style:none;border-width:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:heading {"textAlign":"left","style":{"spacing":{"margin":{"top":"10px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"30px"}},"textColor":"foreground","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-left has-foreground-color has-text-color has-gilda-display-font-family" style="font-size:30px;margin-top:10px;margin-right:0px;margin-bottom:0px;margin-left:0px">Subscription Package</h2>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"flex"}} -->
<div class="wp-block-group"><!-- wp:separator {"className":"has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background"} -->
<hr class="wp-block-separator has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background"/>
<!-- /wp:separator --></div>
<!-- /wp:group -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px","bottom":"10px"}},"border":{"width":"1px","style":"solid"}},"borderColor":"lightgrey"} -->
<div class="wp-block-column has-border-color has-lightgrey-border-color" style="border-style:solid;border-width:1px;margin-top:10px;margin-bottom:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:paragraph {"align":"left","style":{"typography":{"fontStyle":"normal","fontWeight":"400","fontSize":"16px"}},"textColor":"foreground"} -->
<p class="has-text-align-left has-foreground-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400">The balance Secondary School maintains between honoring the past and remaining committed to the future is one of its most compelling attributes. Our alumnae are an incredibly talented, committed and diverse group of people who embody the spirit of our motto, Surgere Tentamus.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px","bottom":"10px"}},"border":{"width":"1px","style":"solid"}},"borderColor":"lightgrey"} -->
<div class="wp-block-column has-border-color has-lightgrey-border-color" style="border-style:solid;border-width:1px;margin-top:10px;margin-bottom:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:paragraph {"align":"left","style":{"typography":{"fontStyle":"normal","fontWeight":"400","fontSize":"16px"}},"textColor":"foreground"} -->
<p class="has-text-align-left has-foreground-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400">We hope you`ll stay in touch, join our network, and bolster our community by supporting Secondary School students today.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"is-style-no-block-gap"} -->
<div class="wp-block-group alignfull is-style-no-block-gap"><!-- wp:cover {"url":"https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/group-children-art-class_236854-20325-1.webp","id":141,"hasParallax":true,"dimRatio":50,"overlayColor":"tertiary","isDark":false} -->
<div class="wp-block-cover is-light has-parallax" style="background-image:url(https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/group-children-art-class_236854-20325-1.webp)"><span aria-hidden="true" class="has-tertiary-background-color wp-block-cover__gradient-background has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"contentSize":"1100px"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"10px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"30px"}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:30px;margin-top:10px;margin-right:0px;margin-bottom:0px;margin-left:0px">Alumni Testimonials</h2>
<!-- /wp:heading -->

<!-- wp:separator {"className":"has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-default"} -->
<hr class="wp-block-separator has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-default"/>
<!-- /wp:separator -->

<!-- wp:columns {"style":{"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}}} -->
<div class="wp-block-columns" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:column {"style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px","bottom":"10px"}},"border":{"style":"none","width":"0px"}}} -->
<div class="wp-block-column" style="border-style:none;border-width:0px;margin-top:10px;margin-bottom:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"bottom":"10px"}}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400;padding-bottom:10px">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"0px","right":"0px","bottom":"5px","left":"0px"}},"typography":{"fontSize":"20px"}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:20px;margin-top:0px;margin-right:0px;margin-bottom:5px;margin-left:0px">Alia Sabur </h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"15px"}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:15px;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px">Teacher Envato</p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":148,"width":70,"height":70,"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":"0px"},"spacing":{"margin":{"top":"10px"}}},"className":"aligncenter size-full is-resized is-style-rounded"} -->
<div class="wp-block-image aligncenter size-full is-resized is-style-rounded" style="border-radius:0px;margin-top:10px"><figure class="aligncenter size-full is-resized"><img src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/portrait-young-smiling-woman.jpg" alt="" class="wp-image-148" width="70" height="70"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"20px","right":"20px","bottom":"20px","left":"20px"},"margin":{"top":"10px","bottom":"10px"}},"border":{"width":"0px","style":"none"}}} -->
<div class="wp-block-column" style="border-style:none;border-width:0px;margin-top:10px;margin-bottom:10px;padding-top:20px;padding-right:20px;padding-bottom:20px;padding-left:20px"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"bottom":"10px"}}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:16px;font-style:normal;font-weight:400;padding-bottom:10px">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"0px","right":"0px","bottom":"5px","left":"0px"}},"typography":{"fontSize":"20px"}},"textColor":"background","fontFamily":"gilda-display"} -->
<h2 class="has-text-align-center has-background-color has-text-color has-gilda-display-font-family" style="font-size:20px;margin-top:0px;margin-right:0px;margin-bottom:5px;margin-left:0px">Jacob Albert</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}},"typography":{"fontSize":"18px"}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:18px;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px">Teacher Envato</p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":149,"width":70,"height":70,"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":"0px"},"spacing":{"margin":{"top":"10px"}}},"className":"aligncenter size-full is-resized is-style-rounded"} -->
<div class="wp-block-image aligncenter size-full is-resized is-style-rounded" style="border-radius:0px;margin-top:10px"><figure class="aligncenter size-full is-resized"><img src="https://themes.websitecarnival.com/school/wp-content/uploads/sites/9/2022/04/smiling-man-with-crossed-arms.jpg" alt="" class="wp-image-149" width="70" height="70"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->